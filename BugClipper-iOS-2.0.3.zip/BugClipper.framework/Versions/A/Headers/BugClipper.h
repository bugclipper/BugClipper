//
//  BugClipper.h
//  BugClipper
//
//  Created by Shwet Solanki on 18/11/14.
//  Copyright (c) 2014 BugClipper. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BCManager.h"

//! Project version number for BugClipper.
FOUNDATION_EXPORT double BugClipperVersionNumber;

//! Project version string for BugClipper.
FOUNDATION_EXPORT const unsigned char BugClipperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BugClipper/PublicHeader.h>
